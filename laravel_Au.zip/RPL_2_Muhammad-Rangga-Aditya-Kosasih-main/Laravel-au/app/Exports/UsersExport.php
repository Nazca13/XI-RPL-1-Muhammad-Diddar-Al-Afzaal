<?php

namespace App\Exports;
use app\Http\Controllers\AdminController;
use App\Models\User;
use Maatwebsite\Excel\Concerns\FromCollection;

class UsersExport implements FromCollection
{
    public function collection()
    {
        return User::all(); // Mengambil semua data pengguna
    }
}