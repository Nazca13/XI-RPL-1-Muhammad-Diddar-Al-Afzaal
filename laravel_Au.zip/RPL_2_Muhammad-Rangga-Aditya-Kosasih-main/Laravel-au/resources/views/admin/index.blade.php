<?php 
use app\Http\Controllers\AdminController;
?>
@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Halaman Admin</h1>

    <!-- Tambahkan tombol ekspor -->
    <a href="{{ route('admin.export') }}" class="btn btn-success mb-3">Ekspor ke Excel</a>

    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($users as $user)
            <tr>
                <td>{{ $user->id }}</td>
                <td>{{ $user->email }}</td>
                <td>
                    <a href="{{ route('admin.edit', $user->id) }}">Edit</a>
                    <form action="{{ route('admin.destroy', $user->id) }}" method="POST" style="display:inline;">
                        @csrf
                        @method('DELETE')
                        <button type="submit">Delete</button>
                    </form>
                </td>
            </tr>
            @endforeach
        </tbody>
    </table>
    <a href="{{ route('admin.create') }}" class="btn btn-primary">Tambah Pengguna</a>
</div>
@endsection