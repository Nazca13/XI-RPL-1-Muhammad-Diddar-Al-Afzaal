@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Selamat datang di Aplikasi Kami</h1>
    <p>Ini adalah halaman utama aplikasi.</p>
</div>
@endsection