<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;
use app\Http\Controllers\AdminController;

Route::get('/', function () {
    return view('home');
});


Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
// Rute untuk halaman admin
Route::get('/admin', [AdminController::class, 'index'])->middleware('auth')->name('admin.index');

// Rute untuk mengekspor data pengguna
Route::get('/admin/export', [AdminController::class, 'export'])->middleware('auth')->name('admin.export');

// Rute resource untuk pengelolaan pengguna
Route::resource('admin', AdminController::class);

Route::post('/auth',[AdminController::class, 'index']);