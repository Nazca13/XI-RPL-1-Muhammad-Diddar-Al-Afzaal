<body>

    <!-- Navbar -->
    <?php include 'header.php'; ?>

    <div class="d-flex" id="wrapper">

        <!-- Sidebar -->
        <?php include 'sidebar.php'; ?>

        <!-- Page Content -->
        <div id="page-content-wrapper">
            <div class="container-fluid">
                <div class="card">
                    <h1>Informasi Saya</h1>
                    <p>Nama:
                        <?php 
            echo "$nama"?>
                    </p>
                    <p>Umur:
                        <?php
            echo "$umur"?>
                    </p>
                    <p>Kelas:
                        <?php
            echo "$kelas"?>
                    </p>
                </div>
            </div>
        </div>
    </div>