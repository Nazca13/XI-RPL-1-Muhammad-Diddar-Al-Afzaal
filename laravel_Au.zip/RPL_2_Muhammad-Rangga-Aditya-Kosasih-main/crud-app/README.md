
```markdown
# Aplikasi Kontak

Aplikasi Kontak ini memungkinkan pengguna untuk menambahkan, melihat, dan menghapus kontak. Aplikasi ini dibangun dengan Laravel dan menggunakan database MySQL.

## Prerequisites

Sebelum memulai, pastikan Anda telah menginstal:

- PHP (versi 7.3 atau lebih tinggi)
- Composer
- MySQL

## Instalasi

Ikuti langkah-langkah di bawah ini untuk menginstal aplikasi ini:

1. **Clone repositori ini:**

   ```bash
   git clone https://github.com/Rangga008/crud-appa.git
   cd crud-app
   ```

2. **Instal dependensi dengan Composer:**

   ```bash
   composer install
   ```

3. **Salin file `.env.example` ke `.env`:**

   ```bash
   cp .env.example .env
   ```

4. **Atur konfigurasi database di file `.env`:**

   Edit bagian berikut dengan informasi database Anda:

   ```plaintext
   DB_CONNECTION=mysql
   DB_HOST=127.0.0.1
   DB_PORT=3306
   DB_DATABASE=nama_database
   DB_USERNAME=root
   DB_PASSWORD=
   ```

5. **Jalankan migrasi untuk membuat tabel yang diperlukan:**

   ```bash
   php artisan migrate
   ```

6. **Jalankan server pengembangan:**

   ```bash
   php artisan serve
   ```

   Aplikasi akan tersedia di `http://localhost:8000`.

## Penggunaan

1. **Menambahkan Kontak:**

   - Buka aplikasi di browser.
   - Isi form dengan nama, email, dan nomor telepon.
   - Klik tombol "Tambah Contact".
   - Jika berhasil, Anda akan melihat pesan sukses dan kontak akan ditambahkan ke daftar.

2. **Melihat Kontak:**

   - Kontak yang telah ditambahkan akan ditampilkan di bawah form input.

3. **Menghapus Kontak:**

   - Klik tombol "Delete" di sebelah kontak yang ingin dihapus.
   - Kontak tersebut akan dihapus dari daftar.

## Catatan

- Jika Anda mencoba menambahkan kontak dengan nomor telepon yang sudah ada, Anda akan menerima pesan kesalahan dan data akan tetap ada di form, sehingga Anda dapat mengeditnya.

## Kontribusi

Jika Anda ingin berkontribusi pada proyek ini, silakan fork repositori ini, buat fitur baru, dan kirimkan pull request.

## Lisensi

Proyek ini dilisensikan di bawah lisensi MIT. Lihat file [LICENSE](LICENSE) untuk detail lebih lanjut.

```

