<?php


$nama = 'Rangga Aditya' ;
$kelas = '11 RPL 2' ;
$jeniskelamin = 'Laki Laki';
$sekolah = 'SMKN 2 Bandung';
$citacita = 'Menjadi Sigma';


?>

<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
    /* Efek transisi smooth saat halaman dimuat */
    body {
        opacity: 0;
        transition: opacity 1s ease-in-out;
    }

    /* Setelah halaman selesai dimuat, ubah opacity menjadi 1 */
    body.loaded {
        opacity: 1;
    }
    </style>
</head>

<body>
    <nav class="navbar bg-body-tertiary">
        <div class="container-fluid btn-danger">
            <a class="navbar-brand" href="#">Home</a>
        </div>
    </nav>
    <div class="container-fluid">
        <div class="row flex-nowrap">
            <div class="col-auto col-md-3 col-xl-2 px-sm-2 px-0 bg-dark">
                <div class="d-flex flex-column align-items-center align-items-sm-start px-3 pt-2 text-white min-vh-100">
                    <a href="/"
                        class="d-flex align-items-center pb-3 mb-md-0 me-md-auto text-white text-decoration-none">
                        <span class="fs-5 d-none d-sm-inline">Menu</span>
                    </a>
                    <ul class="nav nav-pills flex-column mb-sm-auto mb-0 align-items-center align-items-sm-start"
                        id="menu">
                        <li class="nav-item">
                            <a href="index.php" class="nav-link align-middle px-0">
                                <i class="fs-4 bi-house"></i> <span class="ms-1 d-none d-sm-inline">Home</span>
                            </a>
                        </li>
                        <li>
                            <a href="profile.php" data-bs-toggle="collapse" class="nav-link px-0 align-middle">
                                <i class="fs-4 bi-speedometer2"></i>
                                <span class="ms-1 d-none d-sm-inline" href="">Profile</span>
                            </a>

                        </li>
                    </ul>
                    <hr>
                    <div class="dropdown pb-4">
                        <a href="#" class="d-flex align-items-center text-white text-decoration-none dropdown-toggle"
                            id="dropdownUser1" data-bs-toggle="dropdown" aria-expanded="false">
                            <img src="https://github.com/mdo.png" alt="hugenerd" width="30" height="30"
                                class="rounded-circle">
                            <span class="d-none d-sm-inline mx-1">Kuren</span>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-dark text-small shadow">
                            <li><a class="dropdown-item" href="#">New project...</a></li>
                            <li><a class="dropdown-item" href="#">Settings</a></li>
                            <li><a class="dropdown-item" href="#">Profile</a></li>
                            <li>
                                <hr class="dropdown-divider">
                            </li>
                            <li><a class="dropdown-item" href="#">Sign out</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            <div class="col py-3">
                <h1>Nama: <?php echo $nama ;?></h1>
                <h1>Kelas: <?php echo $kelas ;?></h1>
                <h1>Jenis Kelamin: <?php echo $jeniskelamin ;?></h1>
                <h1>Sekolah: <?php echo $sekolah ;?></h1>
                <h1>Cita Cita: <?php echo $citacita ;?></h1>
            </div>
        </div>
    </div>
</body>

<script>
// Tambahkan class 'loaded' setelah halaman selesai dimuat
window.addEventListener('load', function() {
    document.body.classList.add('loaded');
});

// Tambahkan fungsi smooth redirect
function smoothRedirect(url) {
    document.body.classList.remove('loaded');
    setTimeout(function() {
        window.location.href = url;
    }, 1000); // Waktu delay (misalnya 1 detik)
}
</script>

</html>